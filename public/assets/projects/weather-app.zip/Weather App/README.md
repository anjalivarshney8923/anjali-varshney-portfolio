# Weather App - React Learning Project

A beginner-friendly Weather Application built with React to demonstrate fundamental React concepts for academic purposes.

## 📋 Project Overview

This Weather App fetches real-time weather data from OpenWeatherMap API and displays it in a clean, responsive interface. The project is designed to showcase all essential React concepts in a practical, easy-to-understand manner.

## ✨ Features

- 🔍 Search weather by city name
- 🌡️ Display current temperature, humidity, wind speed, and pressure
- 🎨 Responsive design using Bootstrap
- ⚡ Real-time weather data from OpenWeatherMap API
- 🎯 Auto-focus on search input
- ⌨️ Search on Enter key press
- 📱 Mobile-friendly interface

## 🎓 React Concepts Demonstrated

### 1. **Components**
   - `App.jsx` - Main parent component
   - `SearchBar.jsx` - Search input component
   - `WeatherCard.jsx` - Weather display component

### 2. **Props**
   - Passing data from parent to child components
   - `SearchBar` receives: `city`, `setCity`, `onSearch`
   - `WeatherCard` receives: `weather` object

### 3. **Iteration (array.map())**
   - Mapping weather condition array in `WeatherCard`
   - Mapping weather details (humidity, wind, etc.)

### 4. **Conditional Rendering**
   - Show "Loading..." spinner while fetching data
   - Show error message if city not found
   - Show weather card only when data exists
   - Using `&&` and ternary operators

### 5. **Event Handlers**
   - `handleInputChange` - Updates city input
   - `handleKeyPress` - Search on Enter key
   - `onClick` - Search button click

### 6. **useState Hook**
   - `city` - Stores city name input
   - `weather` - Stores fetched weather data
   - `loading` - Manages loading state
   - `error` - Stores error messages

### 7. **useEffect Hook**
   - Auto-focus input field on mount
   - Load default city on component mount
   - Handle side effects (API calls)

### 8. **Refs (useRef)**
   - `inputRef` - Auto-focus search input on page load

### 9. **Data Fetching**
   - Fetch weather data from OpenWeatherMap API
   - Using `fetch()` with async/await
   - Error handling with try-catch

### 10. **Styling**
   - Bootstrap for responsive layout
   - Custom CSS for enhanced UI
   - Mobile-first design approach

## 🚀 How to Run the Project

### Prerequisites
- Node.js (v14 or higher)
- npm or yarn

### Installation Steps

1. **Clone or navigate to the project directory**
   ```bash
   cd "d:\WinterTrainingCRC\Weather App"
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Get API Key**
   - Visit [OpenWeatherMap](https://openweathermap.org/api)
   - Sign up for a free account
   - Get your API key from the dashboard

4. **Add API Key**
   - Open `src/App.jsx`
   - Replace `YOUR_API_KEY_HERE` with your actual API key:
   ```javascript
   const API_KEY = 'your_actual_api_key_here';
   ```

5. **Run the development server**
   ```bash
   npm run dev
   ```

6. **Open in browser**
   - The app will run on `http://localhost:5173`
   - Open this URL in your browser

## 📁 Project Structure

```
Weather App/
├── public/
│   └── vite.svg
├── src/
│   ├── components/
│   │   ├── SearchBar.jsx      # Search input component
│   │   └── WeatherCard.jsx    # Weather display component
│   ├── App.jsx                 # Main app component
│   ├── App.css                 # Custom styles
│   ├── main.jsx                # Entry point
│   └── index.css               # Global styles
├── index.html                  # HTML template with Bootstrap
├── package.json                # Dependencies
└── README.md                   # This file
```

## 🛠️ Technologies Used

- **React** (v19.2.0) - UI library
- **Vite** - Build tool and dev server
- **Bootstrap 5** - CSS framework
- **OpenWeatherMap API** - Weather data
- **HTML5 & CSS3** - Markup and styling

## 📝 Code Highlights

### Component Communication (Props)
```javascript
<SearchBar city={city} setCity={setCity} onSearch={fetchWeather} />
<WeatherCard weather={weather} />
```

### State Management (useState)
```javascript
const [city, setCity] = useState('');
const [weather, setWeather] = useState(null);
const [loading, setLoading] = useState(false);
const [error, setError] = useState('');
```

### Conditional Rendering
```javascript
{loading && <div>Loading...</div>}
{error && <div className="alert">{error}</div>}
{weather && <WeatherCard weather={weather} />}
```

### Iteration (map)
```javascript
{weatherArray.map((item, index) => (
  <div key={index}>{item.description}</div>
))}
```

## 🎯 Learning Outcomes

After studying this project, you will understand:
- How to structure a React application
- Component-based architecture
- State management with hooks
- Props and data flow
- Event handling in React
- API integration and data fetching
- Conditional rendering patterns
- Using refs for DOM manipulation
- Responsive design with Bootstrap

## 📚 Additional Notes

- This is an educational project focusing on React fundamentals
- Code is heavily commented for learning purposes
- API key should be kept secure in production (use environment variables)
- Error handling is implemented for better user experience

## 🤝 Contributing

This is a learning project. Feel free to:
- Add more features (5-day forecast, geolocation, etc.)
- Improve styling
- Add more weather details
- Implement unit tests

## 📄 License

This project is created for educational purposes.

---

**Happy Learning! 🚀**
