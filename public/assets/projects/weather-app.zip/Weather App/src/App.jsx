// App Component - Main Component demonstrating: useState, useEffect, Data Fetching, Conditional Rendering
import { useState, useEffect } from 'react';
import SearchBar from './components/SearchBar';
import WeatherCard from './components/WeatherCard';
import './App.css';

function App() {
  // 6. useState HOOK - Managing multiple states
  const [city, setCity] = useState(''); // Store city name input
  const [weather, setWeather] = useState(null); // Store weather data
  const [loading, setLoading] = useState(false); // Store loading state
  const [error, setError] = useState(''); // Store error messages

  // 9. DATA FETCHING - API key (use your own key from openweathermap.org)
  const API_KEY = '27fa44c941f8d2f15cfee94803c2b073'; // Replace with actual API key
  const API_URL = 'https://api.openweathermap.org/data/2.5/weather';

  // 9. DATA FETCHING - Function to fetch weather data
  const fetchWeather = async () => {
    if (!city.trim()) {
      setError('Please enter a city name');
      return;
    } 

    // 4. CONDITIONAL RENDERING - Set loading state
    setLoading(true);
    setError('');
    setWeather(null);

    try {
      // 7. useEffect - Handle side effects (API call)
      const response = await fetch(
        `${API_URL}?q=${city}&appid=${API_KEY}&units=metric`
      );
      
      if (!response.ok) {
        throw new Error('City not found');
      }

      const data = await response.json();
      setWeather(data); // Update weather state with fetched data
      setError('');
    } catch (err) {
      setError(err.message || 'Failed to fetch weather data');
      setWeather(null);
    } finally {
      setLoading(false);
    }
  };

  // 7. useEffect - Load default city weather on component mount
  useEffect(() => {
    setCity('London');
  }, []);

  return (
    <div className="app-container">
      <div className="container">
        <div className="weather-app">
          {/* Header Section */}
          <div className="app-header">
            <h1 className="app-title">
              <span className="title-icon">☁️</span>
              Weather Forecast
            </h1>
            <p className="app-subtitle">Real-time weather updates worldwide</p>
          </div>

          {/* 1. COMPONENTS & 2. PROPS - Passing props to SearchBar */}
          <SearchBar 
            city={city} 
            setCity={setCity} 
            onSearch={fetchWeather} 
          />

          {/* 4. CONDITIONAL RENDERING - Show loading state */}
          {loading && (
            <div className="loading-container">
              <div className="spinner"></div>
              <p className="loading-text">Fetching weather data...</p>
            </div>
          )}

          {/* 4. CONDITIONAL RENDERING - Show error message */}
          {error && (
            <div className="error-message">
              <span className="error-icon">⚠️</span>
              <span>{error}</span>
            </div>
          )}

          {/* 4. CONDITIONAL RENDERING - Show weather card only when data exists */}
          {weather && !loading && !error && (
            <WeatherCard weather={weather} />
          )}
        </div>
      </div>
    </div>
  );
}

export default App;
