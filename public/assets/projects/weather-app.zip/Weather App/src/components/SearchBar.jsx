// SearchBar Component - Demonstrates: Props, Event Handlers, Refs
import { useRef, useEffect } from 'react';

function SearchBar({ city, setCity, onSearch }) {
  // 8. REFS - useRef to auto-focus input field on page load
  const inputRef = useRef(null);

  // 7. useEffect - Focus input when component mounts
  useEffect(() => {
    inputRef.current.focus();
  }, []);

  // 5. EVENT HANDLERS - Handle input change
  const handleInputChange = (e) => {
    setCity(e.target.value);
  };

  // 5. EVENT HANDLERS - Handle Enter key press
  const handleKeyPress = (e) => {
    if (e.key === 'Enter') {
      onSearch();
    }
  };

  return (
    <div className="search-bar">
      <div className="search-container">
        <input
          ref={inputRef}
          type="text"
          className="search-input"
          placeholder="🔍 Search city..."
          value={city}
          onChange={handleInputChange}
          onKeyPress={handleKeyPress}
        />
        <button className="search-btn" onClick={onSearch}>
          <span>Search</span>
        </button>
      </div>
    </div>
  );
}

export default SearchBar;
