// WeatherCard Component - Demonstrates: Props, Conditional Rendering, Iteration
function WeatherCard({ weather }) {
  // 2. PROPS - Receiving weather data from parent component
  const { name, main, weather: weatherArray, wind, sys } = weather;

  return (
    <div className="weather-card">
      {/* Primary Weather Info */}
      <div className="weather-primary">
        <h2 className="city-name">
          <span className="location-icon">📍</span>
          {name}, {sys.country}
        </h2>
        
        {/* 3. ITERATION - Using map() to display weather condition */}
        {weatherArray.map((item, index) => (
          <div key={index} className="weather-main">
            <img
              src={`https://openweathermap.org/img/wn/${item.icon}@4x.png`}
              alt={item.description}
              className="weather-icon"
            />
            <div className="temp-section">
              <h1 className="temperature">{Math.round(main.temp)}°</h1>
              <p className="weather-description">{item.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Secondary Weather Details */}
      <div className="weather-details">
        {[
          { icon: '🌡️', label: 'Feels Like', value: `${Math.round(main.feels_like)}°C` },
          { icon: '💧', label: 'Humidity', value: `${main.humidity}%` },
          { icon: '💨', label: 'Wind Speed', value: `${wind.speed} m/s` },
          { icon: '🔽', label: 'Pressure', value: `${main.pressure} hPa` }
        ].map((detail, index) => (
          <div key={index} className="detail-item">
            <span className="detail-icon">{detail.icon}</span>
            <div className="detail-content">
              <span className="detail-label">{detail.label}</span>
              <span className="detail-value">{detail.value}</span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export default WeatherCard;
